package com.example.cameraoperator.camera

/**
 * Contract scaffold only. This is NOT a functioning PTP/IP or USB camera driver.
 * Implement it in the Android native layer after inspecting the selected, license-approved
 * SonyPhotoTransfer files and validating against a real camera model/firmware.
 * Never implement listObjects() by silently downloading each original.
 */

 data class CameraObjectMetadata(
    val objectId: String,
    val fileName: String,
    val capturedAtIso: String? = null,
    val sizeBytes: Long? = null,
    val mimeType: String? = null,
    val hasThumbnail: Boolean,
 )

 data class CameraCapabilities(
    val canListObjects: Boolean,
    val canGetThumbnail: Boolean,
    val canDownloadSelectedOriginal: Boolean,
    val protocolPagingSupported: Boolean = false,
 )

 interface CameraGateway {
    suspend fun connect(): CameraCapabilities

    /** Must enumerate object identifiers and metadata only; no original bytes. */
    suspend fun listObjects(offset: Int, limit: Int): List<CameraObjectMetadata>

    /** Returns a small thumbnail only. Return null if the camera has none. */
    suspend fun getThumbnail(objectId: String): ByteArray?

    /** Called only after explicit selection. Stream/copy original into an app-owned temp file. */
    suspend fun downloadSelectedOriginal(
        objectId: String,
        onProgress: (bytesTransferred: Long, totalBytes: Long?) -> Unit,
    ): java.io.File

    /** Must not modify or delete camera-card objects. */
    suspend fun disconnect()
 }
