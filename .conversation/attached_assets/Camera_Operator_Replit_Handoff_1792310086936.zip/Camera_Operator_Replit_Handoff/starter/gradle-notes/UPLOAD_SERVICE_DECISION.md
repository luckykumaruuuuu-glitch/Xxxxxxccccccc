# android-upload-service: dependency decision gate

Official repository: https://github.com/gotev/android-upload-service
Official Releases: https://github.com/gotev/android-upload-service/releases

This helper is marked Apache-2.0 and documents background multipart/binary/FTP upload functionality. No version is pinned in this handoff intentionally, because the latest available release and compatibility must be verified at implementation time.

Before adding it:

1. Check the newest official release/tag and its Maven coordinates.
2. Check the current app's Android target SDK, Gradle/JDK versions, minSdk and Expo/prebuild workflow.
3. Build a small Android proof-of-concept for multipart POST with progress and cancellation.
4. Confirm process-death/restart behavior and retry handling.
5. If the library needs a custom Expo config plugin/native module, estimate that complexity. If it doesn't buy enough, use the project's existing HTTP stack plus durable WorkManager queue instead.

Do not use this library for camera PTP/IP browsing; that is a separate camera-adapter problem. Do not manually set multipart `Content-Type` boundaries in a normal `fetch` multipart request.
