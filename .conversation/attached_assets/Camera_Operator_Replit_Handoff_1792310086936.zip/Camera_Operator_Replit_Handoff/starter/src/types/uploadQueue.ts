export type QueueState =
  | 'queued'
  | 'downloading-original'
  | 'ready-to-upload'
  | 'uploading'
  | 'uploaded'
  | 'import-pending'
  | 'completed'
  | 'failed'
  | 'cancelled';

/** Persist this metadata, not passwords or bearer tokens. */
export interface UploadQueueItem {
  id: string;
  uploadId: string;
  albumId: string;
  cameraObjectId: string;
  originalFileName: string;
  mimeType: string;
  sizeBytes?: number;
  temporaryFileUri?: string;
  state: QueueState;
  attempts: number;
  createdAt: string;
  updatedAt: string;
  lastError?: string;
}

export interface QueueProgress {
  itemId: string;
  state: QueueState;
  bytesSent?: number;
  totalBytes?: number;
  message?: string;
}
