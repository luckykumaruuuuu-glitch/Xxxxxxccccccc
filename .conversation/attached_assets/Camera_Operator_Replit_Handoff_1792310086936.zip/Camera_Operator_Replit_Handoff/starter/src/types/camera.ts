/** Original starter contract for a camera-memory browser.
 * This file intentionally contains no vendor-specific PTP implementation.
 * A native Android module must implement the real camera protocol.
 */

export type CameraTransport = 'wifi-ptpip' | 'usb-ptp' | 'mock';
export type CameraMediaKind = 'image' | 'video' | 'unknown';

export interface CameraInfo {
  id: string;
  manufacturer?: string;
  model?: string;
  firmware?: string;
  transport: CameraTransport;
  connectedAt: string;
}

export interface CameraPhoto {
  /** Stable object handle or vendor-specific object identifier. */
  id: string;
  fileName: string;
  capturedAt?: string;
  sizeBytes?: number;
  mimeType?: string;
  extension?: string;
  mediaKind: CameraMediaKind;
  /** URI for a small thumbnail cache item, not the original photo. */
  thumbnailUri?: string;
  /** True only when adapter confirms thumbnail availability. */
  hasThumbnail: boolean;
}

export interface CameraListPage {
  items: CameraPhoto[];
  /** Optional app-side continuation token. Do not imply remote pagination if protocol lacks it. */
  nextPageToken?: string;
  totalCount?: number;
}

export interface CameraConnectionResult {
  camera: CameraInfo;
  capabilities: {
    browseObjects: boolean;
    fetchThumbnails: boolean;
    downloadSelectedOriginals: boolean;
    remotePagination?: boolean;
  };
}

export interface OriginalDownloadProgress {
  bytesTransferred: number;
  totalBytes?: number;
  fraction?: number;
}

export interface ConnectOptions {
  /** Wi-Fi camera transport may require Android to bind sockets to a network. */
  transport: CameraTransport;
  /** Optional user-selected camera hostname/IP; avoid guessing an IP. */
  endpoint?: string;
}

export interface CameraAdapter {
  readonly adapterId: string;
  canHandle(options: ConnectOptions): Promise<boolean>;
  connect(options: ConnectOptions): Promise<CameraConnectionResult>;
  listObjects(options?: { pageToken?: string; pageSize?: number; refresh?: boolean }): Promise<CameraListPage>;
  /** Loads a small camera-native thumbnail. Must not call downloadOriginal as a fallback. */
  getThumbnail(objectId: string): Promise<{ uri: string } | null>;
  /** Called only after explicit user selection. Does not delete or modify camera objects. */
  downloadOriginal(
    objectId: string,
    destinationUri: string,
    onProgress?: (progress: OriginalDownloadProgress) => void,
  ): Promise<{ uri: string; bytesWritten: number }>;
  disconnect(): Promise<void>;
}

export type CameraConnectionState =
  | { status: 'disconnected' }
  | { status: 'connecting' }
  | { status: 'connected'; camera: CameraInfo }
  | { status: 'error'; message: string; retryable: boolean };
