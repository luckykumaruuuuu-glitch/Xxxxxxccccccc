/**
 * Original API client starter for known WED Faces routes.
 * Confirm endpoint shapes against the current backend before shipping.
 * React Native FormData file objects may need small typing adjustments for your Expo version.
 */

export interface LoginResponse {
  accessToken: string;
  refreshToken: string;
  expiresIn?: number;
  user?: { id?: string; email?: string; [key: string]: unknown };
}

export interface RefreshResponse {
  accessToken: string;
  refreshToken?: string;
  expiresIn?: number;
  [key: string]: unknown;
}

export interface LocalUploadFile {
  uri: string;
  fileName: string;
  mimeType: string;
  sizeBytes?: number;
}

export interface ImportStatus {
  state: 'NONE' | 'RUNNING' | 'COMPLETED' | 'FAILED' | string;
  total?: number;
  imported?: number;
  duplicates?: number;
  failed?: number;
  failures?: unknown[];
  error?: string;
  [key: string]: unknown;
}

export class WedFacesApiError extends Error {
  constructor(
    message: string,
    public readonly status: number,
    public readonly responseBody?: unknown,
  ) {
    super(message);
    this.name = 'WedFacesApiError';
  }
}

function normalizedBaseUrl(baseUrl: string): string {
  const trimmed = baseUrl.trim().replace(/\/+$/, '');
  if (!trimmed) throw new Error('Server URL is required.');
  return trimmed;
}

async function readResponse<T>(response: Response): Promise<T> {
  const text = await response.text();
  let body: unknown = undefined;
  if (text) {
    try { body = JSON.parse(text); } catch { body = text; }
  }
  if (!response.ok) {
    const detail = typeof body === 'string' ? body : JSON.stringify(body ?? {});
    throw new WedFacesApiError(`WED Faces request failed (${response.status}): ${detail}`, response.status, body);
  }
  return body as T;
}

async function jsonRequest<T>(
  baseUrl: string,
  path: string,
  init: RequestInit,
  accessToken?: string,
): Promise<T> {
  const headers = new Headers(init.headers ?? {});
  headers.set('Accept', 'application/json');
  if (init.body && !(init.body instanceof FormData)) headers.set('Content-Type', 'application/json');
  if (accessToken) headers.set('Authorization', `Bearer ${accessToken}`);
  const response = await fetch(`${normalizedBaseUrl(baseUrl)}${path}`, { ...init, headers });
  return readResponse<T>(response);
}

export async function login(
  baseUrl: string,
  email: string,
  password: string,
): Promise<LoginResponse> {
  return jsonRequest<LoginResponse>(baseUrl, '/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email: email.trim(), password }),
  });
}

export async function refreshSession(
  baseUrl: string,
  refreshToken: string,
): Promise<RefreshResponse> {
  return jsonRequest<RefreshResponse>(baseUrl, '/api/auth/refresh', {
    method: 'POST',
    body: JSON.stringify({ refreshToken }),
  });
}

/** Response shape intentionally remains unknown until verified against the current server. */
export async function listAlbums(baseUrl: string, accessToken: string): Promise<unknown> {
  return jsonRequest<unknown>(baseUrl, '/api/albums', { method: 'GET' }, accessToken);
}

const allowedMimeTypes = new Set(['image/jpeg', 'image/png', 'image/webp']);
const allowedExtensions = new Set(['jpg', 'jpeg', 'png', 'webp']);

function validateUploadFile(file: LocalUploadFile): void {
  const ext = file.fileName.split('.').pop()?.toLowerCase() ?? '';
  if (!allowedMimeTypes.has(file.mimeType.toLowerCase()) && !allowedExtensions.has(ext)) {
    throw new Error('This WED Faces import path is documented for JPG/JPEG, PNG and WEBP only.');
  }
  if (file.sizeBytes != null && file.sizeBytes <= 0) throw new Error('The selected file is empty.');
}

/**
 * Upload one user-selected image. Call only after the original has explicitly been selected
 * and is available as an app-owned file URI. Do not call while browsing thumbnails.
 */
export async function uploadSelectedPhoto(args: {
  baseUrl: string;
  accessToken: string;
  albumId: string;
  uploadId: string; // stable UUID generated and persisted by queue before retry
  file: LocalUploadFile;
}): Promise<unknown> {
  validateUploadFile(args.file);
  if (!args.albumId.trim()) throw new Error('Actual album id is required.');
  if (!args.uploadId.trim()) throw new Error('A stable uploadId is required.');

  const form = new FormData();
  form.append('uploadId', args.uploadId);
  const filePart = {
    uri: args.file.uri,
    name: args.file.fileName,
    type: args.file.mimeType || 'application/octet-stream',
  };
  // React Native accepts {uri, name, type}; cast is required by some DOM FormData typings.
  form.append('file', filePart as unknown as Blob);

  const response = await fetch(
    `${normalizedBaseUrl(args.baseUrl)}/api/albums/${encodeURIComponent(args.albumId)}/import/upload`,
    {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        Authorization: `Bearer ${args.accessToken}`,
        // Do NOT set Content-Type manually: fetch must add the multipart boundary.
      },
      body: form,
    },
  );
  return readResponse<unknown>(response);
}

/** Call after the intended batch's selected files were uploaded. */
export async function startAlbumImport(args: {
  baseUrl: string;
  accessToken: string;
  albumId: string;
}): Promise<unknown> {
  if (!args.albumId.trim()) throw new Error('Actual album id is required.');
  return jsonRequest<unknown>(
    args.baseUrl,
    `/api/albums/${encodeURIComponent(args.albumId)}/import`,
    { method: 'POST', body: JSON.stringify({ path: `.device-uploads/${args.albumId}` }) },
    args.accessToken,
  );
}

export async function getAlbumImportStatus(args: {
  baseUrl: string;
  accessToken: string;
  albumId: string;
}): Promise<ImportStatus> {
  return jsonRequest<ImportStatus>(
    args.baseUrl,
    `/api/albums/${encodeURIComponent(args.albumId)}/import/status`,
    { method: 'GET' },
    args.accessToken,
  );
}
