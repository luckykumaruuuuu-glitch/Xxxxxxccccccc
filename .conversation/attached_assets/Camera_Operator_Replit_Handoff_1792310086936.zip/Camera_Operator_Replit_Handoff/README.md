# Camera Operator — Replit Handoff Bundle

**Prepared:** 2026-10-18  
**Purpose:** Start a separate Android-first Camera Operator app that can browse compatible camera memory-card photos without downloading full originals, then upload only selected files to the existing WED Faces API.

## What is in this bundle

- `docs/01_START_HERE_HI.md` — Hindi start guide.
- `docs/02_PROJECT_RANKING.md` — ranked repository decisions.
- `docs/03_LICENSE_AUDIT.md` — license and copying cautions.
- `docs/04_SOURCE_FILE_MAP.md` — which upstream files to inspect / conditionally adapt.
- `docs/05_WED_FACES_API_CONTRACT.md` — known existing API contract.
- `docs/06_REPLIT_AGENT_MASTER_PROMPT.md` — full prompt to give Replit Agent.
- `scripts/download_references.ps1` and `.sh` — download public repos into `reference_sources/` in an internet-enabled workspace.
- `starter/src/` — original starter contracts and WED Faces API service, authored for this handoff (not copied from those repositories).
- `starter/native-android/CameraGateway.kt` — native adapter contract scaffold only; it is not a working PTP implementation.

## Honest download status

This bundle was assembled after inspecting the public GitHub repository pages and their available documentation. The current file-building runtime could not resolve `github.com` for `git clone`/archive download, so **the upstream repository source trees are not embedded in this ZIP**. Use the included download script from Replit Shell or a computer with Git and internet access; it creates `reference_sources/` with the public sources. Do not treat this bundle as a tested APK or as proof that any camera model works.

## Fast start

1. Upload/unzip this bundle in the Replit workspace for the Camera Operator app.
2. Open `docs/06_REPLIT_AGENT_MASTER_PROMPT.md` and submit its whole contents to Replit Agent.
3. If Agent cannot download sources itself, run the matching script:
   - Linux/Replit Shell: `bash scripts/download_references.sh`
   - Windows PowerShell: `./scripts/download_references.ps1`
4. Agent must read each downloaded repository's own `LICENSE`, `NOTICE`, and dependency licenses before adapting code.
5. Build the API/gallery mock first; actual camera protocol testing must wait until a compatible physical camera is available.

## Key decision

The strongest camera-browser reference is SonyPhotoTransfer (Kotlin Android + PTP/IP). The upload helper `android-upload-service` may be usable as a dependency, but its newest release and framework/Android SDK compatibility must be checked at implementation time. Immich, XerahS, USB_PTP_Lib, Camdrop and SFTPGo are reference-only/deferred under the attached license policy.
