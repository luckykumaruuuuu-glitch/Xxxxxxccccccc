$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Dest = Join-Path $Root 'reference_sources'
New-Item -ItemType Directory -Force -Path $Dest | Out-Null
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw 'Git is required. Install Git and retry.' }

function Clone-Full([string]$Name, [string]$Url) {
  $Path = Join-Path $Dest $Name
  if (Test-Path (Join-Path $Path '.git')) {
    Write-Host "Updating shallow checkout: $Name"
    git -C $Path fetch --depth 1 origin
    if ($LASTEXITCODE -ne 0) { throw "git fetch failed: $Name" }
    git -C $Path reset --hard FETCH_HEAD
  } else {
    Write-Host "Cloning: $Name"
    git clone --depth 1 $Url $Path
    if ($LASTEXITCODE -ne 0) { throw "git clone failed: $Name" }
  }
  git -C $Path rev-parse HEAD | Set-Content -Encoding ascii (Join-Path $Path 'ZIP_BUNDLE_COMMIT.txt')
}

function Clone-Sparse([string]$Name, [string]$Url, [string[]]$Patterns) {
  $Path = Join-Path $Dest $Name
  if (Test-Path (Join-Path $Path '.git')) {
    git -C $Path fetch --depth 1 origin
    if ($LASTEXITCODE -ne 0) { throw "git fetch failed: $Name" }
    git -C $Path reset --hard FETCH_HEAD
  } else {
    git clone --depth 1 --filter=blob:none --sparse $Url $Path
    if ($LASTEXITCODE -ne 0) { throw "git clone failed: $Name" }
  }
  & git -C $Path sparse-checkout set --no-cone @Patterns
  if ($LASTEXITCODE -ne 0) { throw "sparse-checkout failed: $Name" }
  git -C $Path checkout
  if ($LASTEXITCODE -ne 0) { throw "checkout failed: $Name" }
  git -C $Path rev-parse HEAD | Set-Content -Encoding ascii (Join-Path $Path 'ZIP_BUNDLE_COMMIT.txt')
}

Clone-Full 'SonyPhotoTransfer' 'https://github.com/Morning-Sea/SonyPhotoTransfer.git'
Clone-Full 'android-upload-service' 'https://github.com/gotev/android-upload-service.git'
Clone-Full 'XerahS-Android' 'https://github.com/unicxrn/XerahS-Android.git'
Clone-Sparse 'Immich' 'https://github.com/immich-app/immich.git' @('/mobile/**', '/LICENSE', '/README.md')
Clone-Full 'Camdrop' 'https://github.com/shakirstudio/Camdrop.git'
Clone-Full 'Android_USB_PTP_Lib' 'https://github.com/terencehonles/Android_USB_PTP_Lib.git'
Clone-Sparse 'SFTPGo' 'https://github.com/drakkan/sftpgo.git' @('/README.md', '/LICENSE', '/NOTICE')

Write-Host ''
Write-Host 'Download finished. Read every LICENSE/NOTICE before using source.'
Write-Host 'Commit IDs are saved as ZIP_BUNDLE_COMMIT.txt in each checkout.'
