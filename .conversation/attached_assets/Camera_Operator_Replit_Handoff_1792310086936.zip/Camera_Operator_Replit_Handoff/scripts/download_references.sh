#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEST="$ROOT/reference_sources"
mkdir -p "$DEST"
command -v git >/dev/null 2>&1 || { echo "ERROR: Git is required." >&2; exit 1; }

clone_full() {
  local name="$1" url="$2"
  if [ -d "$DEST/$name/.git" ]; then
    echo "Already cloned: $name (fetching latest shallow branch)"
    git -C "$DEST/$name" fetch --depth 1 origin
    git -C "$DEST/$name" reset --hard FETCH_HEAD
  else
    echo "Cloning: $name"
    git clone --depth 1 "$url" "$DEST/$name"
  fi
  git -C "$DEST/$name" rev-parse HEAD > "$DEST/$name/ZIP_BUNDLE_COMMIT.txt"
}

clone_sparse() {
  local name="$1" url="$2"
  shift 2
  local -a patterns=("$@")
  if [ -d "$DEST/$name/.git" ]; then
    git -C "$DEST/$name" fetch --depth 1 origin
    git -C "$DEST/$name" reset --hard FETCH_HEAD
  else
    git clone --depth 1 --filter=blob:none --sparse "$url" "$DEST/$name"
  fi
  # --no-cone supports root files and a selected subfolder.
  git -C "$DEST/$name" sparse-checkout set --no-cone "${patterns[@]}"
  git -C "$DEST/$name" checkout
  git -C "$DEST/$name" rev-parse HEAD > "$DEST/$name/ZIP_BUNDLE_COMMIT.txt"
}

clone_full "SonyPhotoTransfer" "https://github.com/Morning-Sea/SonyPhotoTransfer.git"
clone_full "android-upload-service" "https://github.com/gotev/android-upload-service.git"
clone_full "XerahS-Android" "https://github.com/unicxrn/XerahS-Android.git"
clone_sparse "Immich" "https://github.com/immich-app/immich.git" "/mobile/**" "/LICENSE" "/README.md"
clone_full "Camdrop" "https://github.com/shakirstudio/Camdrop.git"
clone_full "Android_USB_PTP_Lib" "https://github.com/terencehonles/Android_USB_PTP_Lib.git"
clone_sparse "SFTPGo" "https://github.com/drakkan/sftpgo.git" "/README.md" "/LICENSE" "/NOTICE"

echo
echo "Finished. Review LICENSE/NOTICE files before using any source."
echo "Commit IDs saved to each checkout's ZIP_BUNDLE_COMMIT.txt."
