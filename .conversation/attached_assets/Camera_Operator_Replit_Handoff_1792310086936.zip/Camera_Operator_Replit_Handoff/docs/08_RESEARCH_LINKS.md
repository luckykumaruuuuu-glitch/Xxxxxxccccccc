# Research links checked for this handoff

Repository pages / docs inspected on 2026-10-18:

- SonyPhotoTransfer root and README: https://github.com/Morning-Sea/SonyPhotoTransfer
- SonyPhotoTransfer license: https://github.com/Morning-Sea/SonyPhotoTransfer/blob/main/LICENSE
- SonyPhotoTransfer LGPL file: https://github.com/Morning-Sea/SonyPhotoTransfer/blob/main/libptp-LGPL-2.1.txt
- SonyPhotoTransfer agent/protocol notes: https://github.com/Morning-Sea/SonyPhotoTransfer/blob/main/AGENTS.md
- Android Upload Service root / Apache-2.0: https://github.com/gotev/android-upload-service
- Android Upload Service Releases: https://github.com/gotev/android-upload-service/releases
- XerahS-Android root: https://github.com/unicxrn/XerahS-Android
- Immich root / AGPL-3.0: https://github.com/immich-app/immich
- Camdrop root: https://github.com/shakirstudio/Camdrop
- Android USB PTP library README / GPL-3.0: https://github.com/terencehonles/Android_USB_PTP_Lib
- SFTPGo root / license / additional terms: https://github.com/drakkan/sftpgo

These links are discovery points, not immutable snapshots. Record commit SHAs from the actual downloaded checkouts before implementation.
