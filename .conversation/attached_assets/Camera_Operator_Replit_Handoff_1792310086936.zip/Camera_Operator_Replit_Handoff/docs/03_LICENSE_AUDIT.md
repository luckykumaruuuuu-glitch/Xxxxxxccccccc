# License review — do not skip

**This is a preliminary engineering checklist, not legal advice.** License compliance depends on the exact files copied, how linked, distributions, modifications and dependencies. Re-check the `LICENSE`, `NOTICE`, copyright headers and transitive dependencies of the exact downloaded revision before shipping.

| Repository | What repository page says | Safe planned handling |
|---|---|---|
| SonyPhotoTransfer | Root MIT. Embedded `app/src/main/java/com/fimagena/libptp/` is stated to be LGPL-2.1; `libptp-LGPL-2.1.txt` and `AGENTS.md` explain modifications. | MIT-covered files may generally be reused under MIT terms with notices retained. `libptp` and any modified files must be treated separately under LGPL-2.1 and complied with. Preserve both licenses; ask legal counsel if distribution model makes LGPL compliance uncertain. |
| android-upload-service | Apache-2.0 | Prefer consuming as a dependency rather than copying source. Preserve license/NOTICE as required and review transitive dependencies. Verify latest release and Android compatibility. |
| XerahS-Android | GPL-3.0 | Reference-only. Do not copy source into the planned app unless you have intentionally chosen and can meet GPL obligations for the covered combined work. |
| Immich | Root AGPL-3.0 | Reference-only. A separate app that merely learns general design is different from copying/combining code; don't copy code in this plan. Check `mobile/` subfolder notices too. |
| Android_USB_PTP_Lib | GPL-3.0 | Reference-only/deferred. Do not integrate in this plan without a deliberate copyleft/release decision. |
| Camdrop | No root LICENSE was visible in the inspected repository listing | No reuse of source code unless the owner supplies an applicable license/permission. Repository being public is not enough. |
| SFTPGo | AGPL-3.0-only plus additional terms; its WebAdmin/WebClient theme has proprietary reuse restrictions | Do not ship or copy it into this app. If separately deploying SFTPGo later, evaluate server licensing and UI/theme restrictions first. |

## Required Agent behavior

- Do not bulk-copy repositories into the target app.
- Keep reference checkouts under `reference_sources/` and outside the app package/build context.
- Build a source-attribution manifest for each upstream file that is actually reused: original URL, commit SHA, original path, license, modified status, included notice location.
- Include full required license texts and notices for any reused component.
- Check direct and transitive dependencies. Do not assume the top-level repository license covers all embedded libraries/assets.
- Do not bypass a license by paraphrasing/copying the file while leaving it uncredited.
- If the agent cannot confidently determine if a file can be used, implement a clean-room interface/independent implementation or leave it out and report the blocker.
