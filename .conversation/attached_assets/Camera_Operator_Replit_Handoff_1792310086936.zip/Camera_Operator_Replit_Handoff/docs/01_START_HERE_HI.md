# शुरू यहाँ से करें

## आपका लक्ष्य

एक अलग Android-first Camera Operator ऐप बनाना है। फोन कैमरे के Wi-Fi या USB/OTG से कनेक्ट होगा; कैमरे की मेमोरी में मौजूद फोटो की सूची, उपलब्ध metadata और thumbnails दिखाएगा। पूरी original files अपने-आप फोन में डाउनलोड नहीं होनी चाहिए। यूज़र जिन फोटो को चुने, उन्हीं originals को transfer कर मौजूदा WED Faces server पर upload करना है।

## यह ZIP क्या तैयार देती है?

- Replit Agent को देने के लिए पूरा master prompt.
- GitHub source references और उन्हें workspace में डाउनलोड करने के scripts.
- लाइसेंस/रैंकिंग और file-by-file निरीक्षण सूची.
- Camera adapter interface और WED Faces API service की शुरुआती TypeScript files.
- Kotlin native-camera bridge का contract scaffold.

## महत्वपूर्ण सीमा

यह production-ready ऐप या APK नहीं है। कैमरा hardware उपलब्ध नहीं होने के कारण live Sony/Canon/Nikon/USB compatibility प्रमाणित नहीं है। ZIP के अंदर आधिकारिक upstream repos की पूरी source trees भी नहीं हैं—इस वातावरण में GitHub clone/download असफल हुआ। Script उन्हें इंटरनेट वाले Replit/PC workspace में खींचने के लिए है।

## मेरी प्राथमिकता

1. पहले UI, login, albums, test-gallery, WED Faces upload/import flow.
2. दूसरा Sony Wi-Fi PTP/IP memory browser; SonyPhotoTransfer की relevant files पढ़कर license-aware integration.
3. उसके बाद चुनी हुई फोटो की transfer queue और retry.
4. USB/PTP/Canon/Nikon adapter बाद के अलग चरण में, वास्तविक hardware के साथ.

RAW formats `.ARW`, `.CR3`, `.NEF` को मौजूदा WED Faces import path में supported न मानें; JPEG/PNG/WEBP path पहले implement/test करें।
