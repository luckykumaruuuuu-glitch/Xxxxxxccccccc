# Source map: exactly where to look

File paths below are **upstream paths to inspect after running the download script**. Since this runtime could not download the upstream repositories, I cannot honestly say these files are already inside this ZIP. Paths can change on a later commit; verify them before use.

## A. SonyPhotoTransfer — highest priority
Repository: https://github.com/Morning-Sea/SonyPhotoTransfer

| Upstream path | What to inspect / use |
|---|---|
| `README.md` | Confirm protocol flow, compatibility notes, build/setup and license summary. Reference only. |
| `AGENTS.md` | Protocol discovery notes and architecture details. Reference only. |
| `LICENSE` | Keep the MIT license and copyright notice if MIT-covered source is reused. |
| `libptp-LGPL-2.1.txt` | Must read before reusing PTP library source. |
| `app/src/main/java/com/fimagena/libptp/` | Core PTP/IP library code; conditional reuse only under LGPL-2.1 terms. Preserve/ship source and notices as required. |
| `app/src/main/java/` (browse current tree) | Locate camera connection, Wi-Fi network binding, thumbnail fetching, camera file listing and selected-object transfer flows. Adapt only specific needed files after per-file license check; don't take Compose UI wholesale. |
| `app/build.gradle.kts` or relevant Gradle files | Dependency versions and Android setup to inspect, not blindly paste into another project. |

Core protocol described in the README: `OpenSession` → `GetStorageIDs` → `GetObjectHandles` → `GetObjectInfo` → `GetThumb(handle)`; only after user selection call `GetObject(handle)` to stream original bytes. The source says PTP/IP port 15740 and a tested target of original Sony ZV-E10 firmware 2.02. Actual target camera must still be verified.

## B. android-upload-service — candidate upload dependency
Repository: https://github.com/gotev/android-upload-service

| Upstream path | What to inspect / use |
|---|---|
| `README.md` | Official integration guide and current dependency coordinates. |
| `uploadservice/` | Core background upload module; source is not normally copied. |
| `uploadservice-okhttp/` | HTTP/OkHttp integration module. |
| `examples/` | Request construction/progress observer examples. |
| `LICENSE` | Apache-2.0 requirements. |
| GitHub Releases page | Check actual latest release at implementation time. |

Use as a dependency only if it builds with the chosen Android target SDK. This project is React Native/Expo-oriented in this plan, so native-library integration may require a custom native module/config plugin; the dependency is not automatically a drop-in one-line fix.

## C. XerahS-Android — upload UI reference only
Repository: https://github.com/unicxrn/XerahS-Android

Inspect `README.md`, `app/`, `core/`, `feature/`, `LICENSE`. Study endpoint/profile configuration and progress UX. Do not copy source; GPL-3.0.

## D. Immich — mobile/background upload reference only
Repository: https://github.com/immich-app/immich

Inspect `mobile/`, root `README.md`, root `LICENSE`, plus all nested license/notice files. Study sign-in/server configuration, background upload and list/virtual-scroll patterns. Do not copy source; root AGPL-3.0.

## E. Camdrop — USB/PTP concept reference only
Repository: https://github.com/shakirstudio/Camdrop

Inspect `README.md`, `app/`, and any license file discovered in the full checkout. README describes `UsbManager`/`MtpDevice` and camera FTP tethering. No source code copying unless an explicit applicable license is discovered.

## F. Android_USB_PTP_Lib — legacy USB/PTP reference only
Repository: https://github.com/terencehonles/Android_USB_PTP_Lib

Inspect `ReadMe.md`, `USBCamera/`, and GPL-3.0 terms. It states certain Canon EOS and Nikon DSLR models worked; it is an old project and not universal camera support. Defer implementation.

## G. SFTPGo — not part of v1
Repository: https://github.com/drakkan/sftpgo

Only inspect `README.md`, `LICENSE`, `NOTICE` if a separate transfer server is considered later. Do not add it to this app. The existing API is enough for v1.

## Files included in this ZIP that you can adapt directly

- `starter/src/types/camera.ts` — TypeScript camera list/adapter contracts.
- `starter/src/types/uploadQueue.ts` — transfer queue item model.
- `starter/src/services/wedFacesApi.ts` — original API client helper covering the known WED Faces routes.
- `starter/native-android/CameraGateway.kt` — Kotlin bridge contract (not a working USB/PTP protocol implementation).

The starter TypeScript assumes a React Native/Expo-style environment. An agent must adapt file imports and native file/form types to the real project and run type/build tests.
