# Project ranking and action decisions

Research snapshot: 2026-10-18. Repository pages can change; Agent must re-check the default branch, recent activity, per-folder licenses and release compatibility before use.

| Rank | Repository | Decision | Reason / action |
|---:|---|---|---|
| 1 | [SonyPhotoTransfer](https://github.com/Morning-Sea/SonyPhotoTransfer) | **Primary camera-browser reference; selective reuse only after license audit** | Kotlin Android app that lists camera objects, reads metadata and thumbnails through PTP/IP, then downloads selected originals. Its main repo says MIT, but it bundles `libptp` under LGPL-2.1. Do not copy its entire UI/app as the WED Faces app. Inspect individual files and preserve notices / LGPL obligations. |
| 2 | [gotev/android-upload-service](https://github.com/gotev/android-upload-service) | **Potential direct dependency, only after compatibility test** | Apache-2.0 library for background multipart/binary uploads, progress and persistent requests. Verify the latest release from its Releases page and integration requirements with the app framework and Android target SDK. Do not hard-code a guessed version. |
| 3 | [Immich](https://github.com/immich-app/immich) (`mobile/`) | **Reference only** | Study server configuration/login and background upload design. Root repository declares AGPL-3.0; inspect any nested license notices before reusing any file. Do not copy code into the app in this plan. It is a large unrelated photo platform. |
| 4 | [XerahS-Android](https://github.com/unicxrn/XerahS-Android) | **Reference only** | Study upload destinations, endpoint settings and UI interaction. Repository declares GPL-3.0. Do not copy code or integrate its modules under this project's current license plan. |
| 5 | [Android_USB_PTP_Lib](https://github.com/terencehonles/Android_USB_PTP_Lib) | **Reference only / defer USB** | Small historic USB PTP project; README says only certain Canon EOS and Nikon DSLR models worked. All code is GPL-3.0. Do not integrate without an explicit copyleft plan and hardware tests. |
| 6 | [Camdrop](https://github.com/shakirstudio/Camdrop) | **Read only; no code copying unless a license is established** | Its README describes Android USB/MTP/PTP, FTP tethering and event-photo workflows. The repository listing has no visible root `LICENSE`; no license means no blanket permission to copy. Learn from high-level behavior only. |
| 7 | [SFTPGo](https://github.com/drakkan/sftpgo) | **Do not use in v1** | Separate server with SFTP/FTP/S/WebDAV; AGPL-3.0-only plus additional terms, and proprietary restrictions for its WebAdmin/WebClient theme. Existing WED Faces API already has upload/import endpoints, so adding this server is unnecessary. |

## Suggested implementation order

1. Use the original starter files included in `starter/src/` as your API/adapter contracts; adapt to the app's actual framework.
2. Implement WED Faces login/albums/selected-file upload/import before the camera adapter.
3. Inspect SonyPhotoTransfer under `reference_sources/SonyPhotoTransfer/` and map file-by-file which Kotlin components to wrap in a native module. Prefer a thin adapter; do not copy unrelated UI.
4. Test `android-upload-service` in a small native build separately. If incompatible, use the app's HTTP stack plus a durable Android WorkManager-based queue.
5. Keep all GPL/AGPL/no-license repositories outside the app's source tree as references.

## Not yet verified

- No local build was run against these upstream repos in the current environment.
- No physical camera was available for connection testing.
- Camera models listed upstream are maintainer-stated, not independently verified here.
- This document is technical guidance, not legal advice.
