# MASTER PROMPT — Camera Operator Android App

You are the implementation agent. Build the project; do not stop after writing a plan. Do not ask for permission after every step. Make reasonable implementation decisions, run available tests/builds, and report blockers accurately. The target is a separate Android-first Camera Operator app, not a modification of WED Faces backend.

## 1) Start by inspecting this bundle and workspace

1. Read every file in `docs/` and `starter/` in this handoff package.
2. Run `scripts/download_references.sh` (or the PowerShell counterpart) if `reference_sources/` does not contain the source checkouts. Use the internet-enabled Replit workspace. If a clone fails, report which repository and continue with the sources that downloaded.
3. Produce an attribution/license inventory with repo URL, commit SHA, license, upstream path and intended use for every file you want to reuse. Inspect root and nested `LICENSE`, `NOTICE`, copyright headers and third-party dependencies.
4. Keep downloaded references outside the app's source/build tree. They are research materials, not modules to bulk-import.
5. Determine the current app framework. If no project exists, use React Native + TypeScript with an Android-first Expo workflow and use a Kotlin native module where camera protocol capabilities require it. The camera PTP/IP code is Android-specific. Do not build a fake web-only camera flow and claim it works on Android hardware.

## 2) Required product behavior

- Minimal premium UI, strictly black and white. No gradients, loud colors, ads, analytics, camera controls unrelated to file transfer or extra screens.
- Keep only necessary sections: **Camera Browse**, **Transfer Queue**, **Settings**.
- Settings: server base URL; login email/password; album picker; camera connection instructions; test gallery toggle clearly labeled as test mode.
- Camera Browse: connected camera/model/status; refresh; grid/list of camera objects with thumbnail, filename, captured time, size and format when provided; multi-select; `Send selected` action.
- Crucial requirement: read the camera memory/object listing and thumbnails without automatically downloading original files. Thumbnail transfers are allowed. Use metadata and camera thumbnail commands only until selection. If the protocol cannot list without downloading the original, show a clear unsupported/limited state; never fake it.
- Handle large cards incrementally. Avoid loading image bytes for all originals, avoid retaining full-resolution images in memory, throttle thumbnail fetching and cache only small thumbnails. Do not assume the protocol supports remote pagination; when it does not, enumerate handles/metadata in bounded chunks on the app side.
- When new shots appear, refresh/re-list without resetting selected files unnecessarily.
- Never delete, rename, edit or format anything on the camera card.
- Transfer only selected originals. Show each file's state/progress/retry/error. Do not tell the user an image has been uploaded until the server confirms it.

## 3) Camera implementation strategy

### First adapter: Sony Wi-Fi PTP/IP

- Use `SonyPhotoTransfer` as the primary technical reference: https://github.com/Morning-Sea/SonyPhotoTransfer
- Its README describes PTP/IP over camera Wi-Fi, port 15740, `OpenSession`, `GetStorageIDs`, `GetObjectHandles`, `GetObjectInfo`, `GetThumb(handle)` and `GetObject(handle)` for original transfer. Investigate current actual source files before implementing; these details are not a substitute for a live-camera test.
- Browse the upstream `app/src/main/java/` tree and locate the actual connection, Wi-Fi network binding, PTP client, object listing, metadata, thumbnail and streaming-download classes. Do not guess file names; record exact paths from the downloaded source.
- Root SonyPhotoTransfer repo is MIT, but `app/src/main/java/com/fimagena/libptp/` is stated to be LGPL-2.1. Do not bulk-copy the full app. Reuse only clearly needed files after checking their license and meet MIT/LGPL notices and source/modified-library obligations. If LGPL compliance is not clear, write a clean independent adapter using public protocol behavior and do not copy the library files.
- Camera Wi-Fi often has no internet route. Use Android network binding as required so camera sockets route to the camera while server uploads use a network with internet. Test switching/dual-network behavior; do not assume simultaneous camera Wi-Fi and mobile data will work on every Android device.
- Compatibility cannot be marked complete until a physical model/firmware is tested. SonyPhotoTransfer's README identifies original ZV-E10 firmware 2.02 as its primary test target; do not claim all Sony models work.

### USB / Canon / Nikon

- Treat `Android_USB_PTP_Lib` as GPL-3.0 reference-only under the current plan.
- Treat Camdrop source as no-copy until an applicable license is established.
- Implement USB/PTP and Canon/Nikon only as separate future adapters and only when supported hardware is available. No universal support claim. No camera available now means use mock-camera/test-gallery mode and clearly label it.

## 4) Upload library decision

- Inspect https://github.com/gotev/android-upload-service . It is Apache-2.0 and may support background multipart uploads, progress and persistent requests.
- Read current README/Release notes and inspect compatibility with current Android target SDK, React Native/Expo/prebuild and chosen native module. Check the latest version from the official release page; do not use a guessed/pasted version.
- Build a tiny upload proof-of-concept first. If incompatible or adds avoidable complexity, use the existing native/React Native HTTP stack plus a durable upload queue and Android background work. Upload service is not a camera-browser library.
- Do not copy from GPL/AGPL reference apps into the app. Immich/XerahS are reference-only; SFTPGo is not part of v1; Camdrop has no copying permission identified in this bundle.

## 5) WED Faces server integration

Use the routes documented in `docs/05_WED_FACES_API_CONTRACT.md`; verify each against the actual current server before shipping. Do not change the WED Faces server/API/database/AI worker and do not invent endpoints.

- Login: `POST /api/auth/login` with email/password; store tokens securely.
- Refresh: `POST /api/auth/refresh` with refreshToken.
- Albums: `GET /api/albums`; use the real album `id`.
- Per selected photo: `POST /api/albums/{albumId}/import/upload` multipart fields `uploadId` (stable UUID) and `file`.
- After the selected batch is uploaded: `POST /api/albums/{albumId}/import` JSON `{ "path": ".device-uploads/{albumId}" }`.
- Poll `GET /api/albums/{albumId}/import/status`; show `NONE`, `RUNNING`, `COMPLETED`, `FAILED` and numeric counters if returned.
- Supported known server formats: JPEG/JPG, PNG, WEBP. Treat RAW formats as unsupported unless confirmed in current backend source. Default known max size 30 MB may be deployment-configurable; verify before enforcing.
- Do not claim AI face indexing complete merely because bytes reached the upload endpoint. Use real import status.
- Do not delete server staging files or camera files; no staging cleanup contract is established here.

## 6) Original-file transfer pipeline

1. Enumerate camera handles and metadata.
2. Fetch small thumbnail data where supported. Cache thumbnails only; do not fetch originals during grid browsing.
3. When a user selects files, validate file type/size and ensure the user has selected the target album.
4. For each selected image, either stream into a temporary app-owned file or use a verified streaming multipart implementation. Because WED Faces currently accepts multipart `file`, do not claim direct camera-to-server streaming unless it is actually implemented and proven. A temporary local file is acceptable for v1.
5. Queue upload with durable metadata: camera ID/model, camera object handle, filename, size, uploadId, albumId, state, retries and timestamps. Keep tokens out of the queue logs.
6. On network failure, retain the selected item and provide retry. Avoid duplicate import requests. After server upload/import is confirmed, remove app-owned temporary originals according to a documented cleanup policy, but never remove camera-card files.
7. Support cancellation without corrupting queue state. Report failures per file.

## 7) Original starter files

Review and adapt these files rather than duplicating their contract:
- `starter/src/types/camera.ts`
- `starter/src/types/uploadQueue.ts`
- `starter/src/services/wedFacesApi.ts`
- `starter/native-android/CameraGateway.kt`

The TypeScript starter is generic React Native/Expo style, not a drop-in full app. Fix typing/build errors against the real project. The Kotlin gateway is only an interface contract—not a PTP implementation.

## 8) Tests that must exist

- API client tests: login success/failure; token handling; album-list error; multipart upload request uses `uploadId` and actual file field; import body path uses actual `albumId`; status state handling.
- Camera adapter contract tests using fake data. Ensure browsing calls list/thumbnail methods but never `downloadOriginal` until selection.
- Queue tests: retry, cancel, duplicates, network loss, partial failure and app restart persistence.
- Gallery mock: display a clear `TEST MODE — no camera connected` badge/status and never simulate real camera connectivity.
- If no physical camera is available, say live camera integration is not verified. Do not convert mock test success into real-camera support.
- Build the Android app (debug) and run tests available in the workspace. Return actual build/test output or exact blocker, not a made-up success.

## 9) Delivery checklist

- App runs in test-gallery mode.
- Server login and album selection work against the configured server.
- A selected test JPEG uploads, album import starts, and status is polled.
- Camera adapter boundary is real and clean; no fake PTP success.
- License/source attribution manifest is included.
- UI remains black/white and minimal.
- Final report lists files changed, libraries added with actual versions, tests/build results, known limitations, and camera models actually tested.
