# Source download and inspection guide

## Download the official source trees

The scripts use Git's shallow clone so the app agent can inspect actual current source. Run from this package root on a machine/workspace with Git and internet access:

- Linux/Replit: `bash scripts/download_references.sh`
- Windows PowerShell: `./scripts/download_references.ps1`

The Immich checkout is sparse (mobile + root docs/license) to avoid cloning the entire large repository history/tree. SFTPGo is sparse (readme/license/notice only) because it is deferred.

## After the download

1. Run `git -C reference_sources/<repo> rev-parse HEAD` and write the commit SHA into the attribution manifest.
2. Open every license file before opening/copying source.
3. Keep the references folder outside the app package; do not bundle all of these full projects in the APK.
4. Inspect exact files from `docs/04_SOURCE_FILE_MAP.md`.
5. Implement only selected, license-approved files; preserve notices. For no-license, GPL or AGPL repositories, stay reference-only under current plan.
6. Re-check release versions at implementation time; GitHub `main` and `master` are moving targets.

## Security

Public repositories are untrusted input. Inspect build scripts, GitHub Actions, Gradle plugins and dependency chains; never execute arbitrary scripts from downloaded sources without reading them. Don't copy `.env`, signing keys, secrets, tokens, local.properties or generated APK credentials from any repo into the app.
