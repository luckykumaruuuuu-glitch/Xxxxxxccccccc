# Existing WED Faces API contract for the app

This reflects the current project integration notes available for this handoff. Verify exact response shapes against the current server checkout/OpenAPI/controller code before finalizing the integration. Do not add new endpoints or modify the server as part of this app task.

## Known routes

1. `POST /api/auth/login`
   - JSON body: `{"email":"...","password":"..."}`
   - Known response fields: `accessToken`, `refreshToken`, `expiresIn`, `user.id`, `user.email`.
2. `POST /api/auth/refresh`
   - JSON body: `{"refreshToken":"..."}`.
3. `GET /api/albums`
   - Bearer access token.
   - Inspect actual response to locate album `id`, name and any display fields. Use the real album UUID/`id`, not `publicId`.
4. `POST /api/albums/{albumId}/import/upload`
   - Multipart fields: `uploadId` (stable UUID for that uploaded object) and `file` (actual image file).
   - Use `Authorization: Bearer <accessToken>`.
5. `POST /api/albums/{albumId}/import`
   - JSON body: `{"path":".device-uploads/{albumId}"}` using that album's actual ID.
6. `GET /api/albums/{albumId}/import/status`
   - Known response fields: `state`, `total`, `imported`, `duplicates`, `failed`, `failures`, `error`.
   - Known states: `NONE`, `RUNNING`, `COMPLETED`, `FAILED`.

## Supported format and status caution

- Existing import format notes list JPG/JPEG, PNG and WEBP as supported; do not promise RAW `.ARW`, `.CR3`, `.NEF` import without server work.
- Default maximum photo size has been noted as 30 MB, but deployment configuration may differ. Check current server config before enforcing it in the UI.
- An upload HTTP success does not necessarily mean the album import/AI pipeline is complete. Poll the import-status endpoint and show honest states.
- Upload/import routes require the appropriate authorized user token. Do not invent an upload-only credential or hard-code admin credentials.
- Avoid deleting server staging objects unless the existing server contract explicitly confirms a safe cleanup endpoint. No such cleanup endpoint is known here.

## Security rules

- Save refresh/access tokens using platform secure storage (Android Keystore-backed SecureStore), not plain-text logs or source files.
- Keep server URL configurable. Use HTTPS for remote servers; only allow HTTP for an explicitly enabled local development host.
- Never log passwords, tokens or entire upload URLs containing secrets.
- Handle token expiry, 401 responses, upload retries, duplicate imports and network loss. Do not blindly retry a non-idempotent action without understanding server semantics.
